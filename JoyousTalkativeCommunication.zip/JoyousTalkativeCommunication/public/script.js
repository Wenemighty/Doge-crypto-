
let currentUser = null;
let currentTaskId = null;
let currentAdminTab = 'users';

// Authentication functions
async function login() {
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    
    if (!username || !email) {
        showNotification('Please enter both username and email', 'error');
        return;
    }
    
    try {
        showLoading(true);
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, email }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            showDashboard();
            await loadTasks();
            await loadWithdrawals();
            showNotification('Welcome back!', 'success');
        } else {
            showNotification(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function register() {
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const wallet = document.getElementById('wallet').value.trim();
    const referralCode = document.getElementById('referral-code').value.trim();
    
    if (!username || !email || !wallet) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    try {
        showLoading(true);
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, email, wallet, referralCode }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            showDashboard();
            await loadTasks();
            await loadWithdrawals();
            showNotification('Account created successfully!', 'success');
        } else {
            showNotification(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

function showDashboard() {
    document.getElementById('auth-section').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
    document.getElementById('user-name').textContent = currentUser.username;
    document.getElementById('balance').textContent = currentUser.balance.toFixed(6);
    document.getElementById('user-status').textContent = currentUser.status;
    document.getElementById('user-status').className = `stat-value status-${currentUser.status}`;
    
    // Show admin features if user is admin
    console.log('User admin status:', currentUser.isAdmin);
    console.log('User email:', currentUser.email);
    
    if (currentUser.isAdmin) {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = el.classList.contains('admin-indicator') ? 'inline-flex' : 'block';
        });
        document.getElementById('admin-nav-btn').style.display = 'block';
        loadAdminData();
        
        // Show notification for admin access
        setTimeout(() => {
            showNotification('🔑 Admin access granted! You can now manage the platform.', 'success');
        }, 1000);
    } else {
        // Hide admin features for non-admin users
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = 'none';
        });
        document.getElementById('admin-nav-btn').style.display = 'none';
    }
}

function logout() {
    currentUser = null;
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('auth-section').style.display = 'block';
    document.getElementById('username').value = '';
    document.getElementById('email').value = '';
    document.getElementById('wallet').value = '';
    
    // Hide admin features
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = 'none';
    });
    
    showNotification('Logged out successfully', 'info');
}

function showSection(section) {
    // Update navigation
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[onclick="showSection('${section}')"]`).classList.add('active');
    
    // Show/hide sections
    document.querySelectorAll('.content-section').forEach(sec => {
        sec.style.display = 'none';
    });
    document.getElementById(`${section}-section`).style.display = 'block';
    
    // Load section data
    if (section === 'tasks') {
        loadTasks();
    } else if (section === 'withdrawals') {
        loadWithdrawals();
    } else if (section === 'referrals') {
        loadReferralStats();
    } else if (section === 'leaderboard') {
        loadLeaderboard();
    } else if (section === 'admin' && currentUser.isAdmin) {
        loadAdminData();
    }
}

// Task functions
async function loadTasks() {
    try {
        const response = await fetch(`/api/tasks/${currentUser.username}`);
        const data = await response.json();
        
        const tasksList = document.getElementById('tasks-list');
        tasksList.innerHTML = '';
        
        data.tasks.forEach(task => {
            const taskCard = document.createElement('div');
            taskCard.className = `task-card ${task.completed ? 'completed' : ''}`;
            
            taskCard.innerHTML = `
                <div class="task-info">
                    <h4>${task.title}</h4>
                    <p class="task-description">${task.description || 'Complete this task to earn rewards'}</p>
                    <div class="task-reward">+${task.reward} TON</div>
                </div>
                <button onclick="openTaskModal('${task.id}')" ${task.completed ? 'disabled' : ''}>
                    ${task.completed ? '<i class="fas fa-check"></i> Completed' : '<i class="fas fa-play"></i> Start Task'}
                </button>
            `;
            
            tasksList.appendChild(taskCard);
        });
    } catch (error) {
        showNotification('Failed to load tasks', 'error');
    }
}

function openTaskModal(taskId) {
    currentTaskId = taskId;
    
    // Find task details
    fetch(`/api/tasks/${currentUser.username}`)
        .then(response => response.json())
        .then(data => {
            const task = data.tasks.find(t => t.id === taskId);
            if (task) {
                document.getElementById('task-title').textContent = task.title;
                document.getElementById('task-description').textContent = task.description || 'Complete this task to earn rewards';
                
                const taskLink = document.getElementById('task-link');
                if (task.url) {
                    taskLink.href = task.url;
                    taskLink.style.display = 'inline-flex';
                } else {
                    taskLink.style.display = 'none';
                }
            }
        });
    
    document.getElementById('task-modal').style.display = 'flex';
    document.getElementById('captcha-check').checked = false;
    document.getElementById('complete-task-btn').disabled = true;
}

function closeTaskModal() {
    document.getElementById('task-modal').style.display = 'none';
    currentTaskId = null;
}

function verifyCaptcha() {
    const isChecked = document.getElementById('captcha-check').checked;
    document.getElementById('complete-task-btn').disabled = !isChecked;
}

async function completeTask() {
    if (!currentTaskId) return;
    
    try {
        showLoading(true);
        const response = await fetch('/api/complete-task', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: currentUser.username,
                taskId: currentTaskId,
                captchaToken: 'verified'
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            currentUser.balance = data.newBalance;
            document.getElementById('balance').textContent = currentUser.balance.toFixed(6);
            closeTaskModal();
            await loadTasks();
        } else {
            showNotification(data.error || 'Failed to complete task', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

// Withdrawal functions
function showWithdrawModal() {
    document.getElementById('withdraw-modal').style.display = 'flex';
}

function closeWithdrawModal() {
    document.getElementById('withdraw-modal').style.display = 'none';
}

async function submitWithdrawal(event) {
    event.preventDefault();
    
    const amount = parseFloat(document.getElementById('withdraw-amount').value);
    const method = document.getElementById('withdraw-method').value;
    const address = document.getElementById('withdraw-address').value.trim();
    
    if (!amount || !method || !address) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    try {
        showLoading(true);
        const response = await fetch('/api/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: currentUser.username,
                amount,
                method,
                address
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            currentUser.balance = data.newBalance;
            document.getElementById('balance').textContent = currentUser.balance.toFixed(6);
            closeWithdrawModal();
            await loadWithdrawals();
            
            // Reset form
            document.getElementById('withdraw-amount').value = '';
            document.getElementById('withdraw-method').value = '';
            document.getElementById('withdraw-address').value = '';
        } else {
            showNotification(data.error || 'Withdrawal failed', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function loadWithdrawals() {
    try {
        const response = await fetch(`/api/withdrawals/${currentUser.username}`);
        const data = await response.json();
        
        const withdrawalsList = document.getElementById('withdrawals-list');
        withdrawalsList.innerHTML = '';
        
        if (data.withdrawals.length === 0) {
            withdrawalsList.innerHTML = '<p style="text-align: center; opacity: 0.7;">No withdrawals yet</p>';
            return;
        }
        
        data.withdrawals.forEach(withdrawal => {
            const withdrawalItem = document.createElement('div');
            withdrawalItem.className = 'withdrawal-item';
            
            withdrawalItem.innerHTML = `
                <div>
                    <strong>${withdrawal.amount} TON</strong><br>
                    <small>${withdrawal.method} - ${withdrawal.address.substring(0, 20)}...</small><br>
                    <small><i class="fas fa-calendar"></i> ${new Date(withdrawal.createdAt).toLocaleDateString()}</small>
                </div>
                <span class="withdrawal-status ${withdrawal.status}">${withdrawal.status}</span>
            `;
            
            withdrawalsList.appendChild(withdrawalItem);
        });
    } catch (error) {
        console.error('Failed to load withdrawals:', error);
    }
}

// Admin functions
function showAdminTab(tab) {
    currentAdminTab = tab;
    
    // Update tab buttons
    document.querySelectorAll('.admin-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[onclick="showAdminTab('${tab}')"]`).classList.add('active');
    
    // Show/hide tab content
    document.querySelectorAll('.admin-tab-content').forEach(content => {
        content.style.display = 'none';
    });
    document.getElementById(`admin-${tab}`).style.display = 'block';
    
    // Load tab data
    if (tab === 'users') {
        loadAdminUsers();
    } else if (tab === 'tasks') {
        loadAdminTasks();
    } else if (tab === 'withdrawals') {
        loadAdminWithdrawals();
    } else if (tab === 'settings') {
        loadAdminSettings();
    }
}

async function loadAdminData() {
    showAdminTab(currentAdminTab);
}

async function loadAdminUsers() {
    try {
        const response = await fetch(`/api/admin/users?adminEmail=${currentUser.email}`);
        const data = await response.json();
        
        const usersList = document.getElementById('users-list');
        usersList.innerHTML = '';
        
        data.users.forEach(user => {
            const userItem = document.createElement('div');
            userItem.className = 'admin-item';
            
            userItem.innerHTML = `
                <div class="admin-item-info">
                    <strong>${user.username}</strong> (${user.email})<br>
                    <small>Balance: ${user.balance.toFixed(6)} TON | Tasks: ${user.completedTasks} | Status: ${user.status}</small><br>
                    <small>Joined: ${new Date(user.createdAt).toLocaleDateString()}</small>
                </div>
                <div class="admin-item-actions">
                    <button class="btn-warning" onclick="showBalanceModal('${user.username}')">
                        <i class="fas fa-coins"></i> Balance
                    </button>
                    <button class="${user.status === 'active' ? 'btn-danger' : 'btn-success'}" 
                            onclick="toggleUserStatus('${user.username}', '${user.status}')">
                        <i class="fas fa-${user.status === 'active' ? 'ban' : 'check'}"></i> 
                        ${user.status === 'active' ? 'Ban' : 'Unban'}
                    </button>
                </div>
            `;
            
            usersList.appendChild(userItem);
        });
    } catch (error) {
        showNotification('Failed to load users', 'error');
    }
}

async function loadAdminTasks() {
    try {
        const response = await fetch(`/api/tasks/${currentUser.username}`);
        const data = await response.json();
        
        const tasksList = document.getElementById('admin-tasks-list');
        tasksList.innerHTML = '';
        
        data.tasks.forEach(task => {
            const taskItem = document.createElement('div');
            taskItem.className = 'admin-item';
            
            taskItem.innerHTML = `
                <div class="admin-item-info">
                    <strong>${task.title}</strong><br>
                    <small>Reward: ${task.reward} TON | Type: ${task.type}</small><br>
                    <small>${task.description || 'No description'}</small>
                </div>
                <div class="admin-item-actions">
                    <button class="btn-danger" onclick="deleteTask('${task.id}')">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            `;
            
            tasksList.appendChild(taskItem);
        });
    } catch (error) {
        showNotification('Failed to load tasks', 'error');
    }
}

async function loadAdminWithdrawals() {
    try {
        const response = await fetch(`/api/admin/withdrawals?adminEmail=${currentUser.email}`);
        const data = await response.json();
        
        const withdrawalsList = document.getElementById('admin-withdrawals-list');
        withdrawalsList.innerHTML = '';
        
        data.withdrawals.forEach(withdrawal => {
            const withdrawalItem = document.createElement('div');
            withdrawalItem.className = 'admin-item';
            
            withdrawalItem.innerHTML = `
                <div class="admin-item-info">
                    <strong>${withdrawal.username}</strong> - ${withdrawal.amount} TON<br>
                    <small>${withdrawal.method} - ${withdrawal.address}</small><br>
                    <small>Requested: ${new Date(withdrawal.createdAt).toLocaleDateString()}</small>
                </div>
                <div class="admin-item-actions">
                    ${withdrawal.status === 'pending' ? `
                        <button class="btn-success" onclick="approveWithdrawal('${withdrawal.id}', 'approve')">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn-danger" onclick="approveWithdrawal('${withdrawal.id}', 'reject')">
                            <i class="fas fa-times"></i> Reject
                        </button>
                    ` : `
                        <span class="withdrawal-status ${withdrawal.status}">${withdrawal.status}</span>
                    `}
                </div>
            `;
            
            withdrawalsList.appendChild(withdrawalItem);
        });
    } catch (error) {
        showNotification('Failed to load withdrawals', 'error');
    }
}

async function loadAdminSettings() {
    try {
        const response = await fetch(`/api/admin/settings?adminEmail=${currentUser.email}`);
        const data = await response.json();
        
        document.getElementById('faucetpay-api').value = data.settings.faucetpayApiKey || '';
        document.getElementById('min-withdrawal-faucetpay').value = data.settings.minWithdrawalFaucetpay;
        document.getElementById('min-withdrawal-other').value = data.settings.minWithdrawalOther;
        document.getElementById('withdrawal-fee-other').value = data.settings.withdrawalFeeOther || 0.01;
        document.getElementById('auto-approve-faucetpay').checked = data.settings.autoApproveFaucetpay;
        document.getElementById('referral-bonus').value = data.settings.referralBonus || 0.0001;
        document.getElementById('referral-commission').value = data.settings.referralCommission || 0.2;
    } catch (error) {
        showNotification('Failed to load settings', 'error');
    }
}

function showAddTaskModal() {
    document.getElementById('add-task-modal').style.display = 'flex';
}

function closeAddTaskModal() {
    document.getElementById('add-task-modal').style.display = 'none';
}

async function addTask(event) {
    event.preventDefault();
    
    const title = document.getElementById('new-task-title').value.trim();
    const description = document.getElementById('new-task-description').value.trim();
    const reward = parseFloat(document.getElementById('new-task-reward').value);
    const type = document.getElementById('new-task-type').value;
    const url = document.getElementById('new-task-url').value.trim();
    
    try {
        showLoading(true);
        const response = await fetch('/api/admin/task/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adminEmail: currentUser.email,
                title,
                description,
                reward,
                type,
                url
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Task added successfully!', 'success');
            closeAddTaskModal();
            loadAdminTasks();
            
            // Reset form
            document.getElementById('new-task-title').value = '';
            document.getElementById('new-task-description').value = '';
            document.getElementById('new-task-reward').value = '';
            document.getElementById('new-task-type').value = '';
            document.getElementById('new-task-url').value = '';
        } else {
            showNotification(data.error || 'Failed to add task', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    
    try {
        const response = await fetch(`/api/admin/task/${taskId}?adminEmail=${currentUser.email}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Task deleted successfully!', 'success');
            loadAdminTasks();
        } else {
            showNotification(data.error || 'Failed to delete task', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
}

async function toggleUserStatus(username, currentStatus) {
    const action = currentStatus === 'active' ? 'ban' : 'unban';
    
    if (!confirm(`Are you sure you want to ${action} this user?`)) return;
    
    try {
        const response = await fetch('/api/admin/user/ban', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adminEmail: currentUser.email,
                username,
                action
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(`User ${action}ned successfully!`, 'success');
            loadAdminUsers();
        } else {
            showNotification(data.error || 'Failed to update user status', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
}

function showBalanceModal(username) {
    const action = prompt('Enter action (add/remove):');
    if (!action || !['add', 'remove'].includes(action)) return;
    
    const amount = prompt('Enter amount:');
    if (!amount || isNaN(amount)) return;
    
    updateUserBalance(username, parseFloat(amount), action);
}

async function updateUserBalance(username, amount, action) {
    try {
        const response = await fetch('/api/admin/user/update-balance', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adminEmail: currentUser.email,
                username,
                amount,
                action
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(`Balance ${action}ed successfully! New balance: ${data.newBalance.toFixed(6)} TON`, 'success');
            loadAdminUsers();
        } else {
            showNotification(data.error || 'Failed to update balance', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
}

async function approveWithdrawal(withdrawalId, action) {
    try {
        const response = await fetch('/api/admin/withdrawal/approve', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adminEmail: currentUser.email,
                withdrawalId,
                action
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(`Withdrawal ${action}d successfully!`, 'success');
            loadAdminWithdrawals();
        } else {
            showNotification(data.error || 'Failed to process withdrawal', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    }
}

async function saveSettings() {
    const faucetpayApiKey = document.getElementById('faucetpay-api').value.trim();
    const minWithdrawalFaucetpay = parseFloat(document.getElementById('min-withdrawal-faucetpay').value);
    const minWithdrawalOther = parseFloat(document.getElementById('min-withdrawal-other').value);
    const withdrawalFeeOther = parseFloat(document.getElementById('withdrawal-fee-other').value);
    const autoApproveFaucetpay = document.getElementById('auto-approve-faucetpay').checked;
    const referralBonus = parseFloat(document.getElementById('referral-bonus').value);
    const referralCommission = parseFloat(document.getElementById('referral-commission').value);
    
    try {
        showLoading(true);
        const response = await fetch('/api/admin/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adminEmail: currentUser.email,
                faucetpayApiKey,
                minWithdrawalFaucetpay,
                minWithdrawalOther,
                withdrawalFeeOther,
                autoApproveFaucetpay,
                referralBonus,
                referralCommission
            }),
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Settings saved successfully!', 'success');
        } else {
            showNotification(data.error || 'Failed to save settings', 'error');
        }
    } catch (error) {
        showNotification('Network error. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

// Referral functions
async function loadReferralStats() {
    try {
        const response = await fetch(`/api/referral-stats/${currentUser.username}`);
        const data = await response.json();
        
        document.getElementById('referral-count').textContent = data.stats.referrals;
        document.getElementById('referral-earnings').textContent = data.stats.referralEarnings.toFixed(6);
        document.getElementById('user-referral-code').value = data.stats.referralCode;
        document.getElementById('referral-bonus').textContent = data.stats.referralBonus;
        document.getElementById('referral-commission').textContent = (data.stats.referralCommission * 100).toFixed(0);
    } catch (error) {
        console.error('Failed to load referral stats:', error);
    }
}

function copyReferralCode() {
    const referralCode = document.getElementById('user-referral-code');
    referralCode.select();
    document.execCommand('copy');
    showNotification('Referral code copied to clipboard!', 'success');
}

// Leaderboard functions
async function loadLeaderboard() {
    try {
        const response = await fetch('/api/leaderboard');
        const data = await response.json();
        
        const leaderboardList = document.getElementById('leaderboard-list');
        leaderboardList.innerHTML = '';
        
        if (data.leaderboard.length === 0) {
            leaderboardList.innerHTML = '<p style="text-align: center; opacity: 0.7;">No users yet</p>';
            return;
        }
        
        data.leaderboard.forEach((user, index) => {
            const rank = index + 1;
            const leaderboardItem = document.createElement('div');
            leaderboardItem.className = 'leaderboard-item';
            
            leaderboardItem.innerHTML = `
                <div class="rank ${rank <= 3 ? 'rank-' + rank : ''}">#${rank}</div>
                <div class="leaderboard-info">
                    <strong>${user.username}</strong><br>
                    <small>Tasks: ${user.completedTasks} | Referrals: ${user.referrals}</small>
                </div>
                <div class="leaderboard-earnings">${user.totalEarnings.toFixed(6)} TON</div>
            `;
            
            leaderboardList.appendChild(leaderboardItem);
        });
    } catch (error) {
        console.error('Failed to load leaderboard:', error);
    }
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    
    // Add styles if not exist
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.innerHTML = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 12px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
                animation: slideInRight 0.3s ease-out;
                max-width: 400px;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            }
            .notification-success { background: rgba(74, 222, 128, 0.9); }
            .notification-error { background: rgba(248, 113, 113, 0.9); }
            .notification-info { background: rgba(59, 130, 246, 0.9); }
            .notification i { margin-right: 10px; }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

function showLoading(show) {
    let loader = document.getElementById('loading-overlay');
    
    if (show && !loader) {
        loader = document.createElement('div');
        loader.id = 'loading-overlay';
        loader.innerHTML = `
            <div class="loading-spinner">
                <i class="fas fa-spinner fa-spin"></i>
                <p>Loading...</p>
            </div>
        `;
        
        // Add styles if not exist
        if (!document.querySelector('#loading-styles')) {
            const styles = document.createElement('style');
            styles.id = 'loading-styles';
            styles.innerHTML = `
                #loading-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.7);
                    backdrop-filter: blur(5px);
                    z-index: 10000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .loading-spinner {
                    text-align: center;
                    color: white;
                }
                .loading-spinner i {
                    font-size: 3rem;
                    margin-bottom: 15px;
                    color: #ffd700;
                }
                .loading-spinner p {
                    font-size: 1.2rem;
                    font-weight: 500;
                }
            `;
            document.head.appendChild(styles);
        }
        
        document.body.appendChild(loader);
    } else if (!show && loader) {
        loader.remove();
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = ['task-modal', 'withdraw-modal', 'add-task-modal'];
    
    modals.forEach(modalId => {
        const modal = document.getElementById(modalId);
        if (event.target === modal) {
            modal.style.display = 'none';
            if (modalId === 'task-modal') {
                currentTaskId = null;
            }
        }
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Set default section
    showSection('tasks');
});
