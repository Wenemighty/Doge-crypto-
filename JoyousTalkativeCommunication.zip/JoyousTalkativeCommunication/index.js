
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// In-memory storage (use database in production)
const users = new Map();
const tasks = new Map();
const withdrawals = new Map();
const adminSettings = new Map();
const referrals = new Map();

// Admin email
const ADMIN_EMAIL = 'Wenem0819@gmail.com';

// Initialize admin settings
adminSettings.set('faucetpay_api_key', '');
adminSettings.set('min_withdrawal_faucetpay', 0.0003);
adminSettings.set('min_withdrawal_other', 0.05);
adminSettings.set('withdrawal_fee_other', 0.01);
adminSettings.set('auto_approve_faucetpay', true);
adminSettings.set('referral_bonus', 0.0001);
adminSettings.set('referral_commission', 0.2);

// Default tasks
const defaultTasks = [
  { id: '1', title: 'Watch Video Ad', reward: 0.0003, type: 'video', description: 'Watch a 30-second advertisement video', url: 'https://example.com/ad1' },
  { id: '2', title: 'Complete Survey', reward: 0.0003, type: 'survey', description: 'Fill out a short survey about your preferences', url: 'https://example.com/survey1' },
  { id: '3', title: 'Visit Website', reward: 0.0003, type: 'visit', description: 'Visit our partner website for 10 seconds', url: 'https://example.com/partner1' },
  { id: '4', title: 'Social Media Follow', reward: 0.0003, type: 'social', description: 'Follow our social media accounts', url: 'https://twitter.com/example' },
  { id: '5', title: 'App Download', reward: 0.0003, type: 'download', description: 'Download and try our partner app', url: 'https://play.google.com/store/apps/details?id=com.example' }
];

defaultTasks.forEach(task => tasks.set(task.id, task));

// Helper function to check if user is admin
function isAdmin(email) {
  return email === ADMIN_EMAIL;
}

// Helper function to check if user is admin by username
function isAdminUser(user) {
  return user && user.email === ADMIN_EMAIL;
}

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// User registration/login
app.post('/api/register', (req, res) => {
  const { username, email, wallet, referralCode } = req.body;
  
  if (!username || !email || !wallet) {
    return res.status(400).json({ error: 'Username, email and wallet required' });
  }
  
  if (users.has(username)) {
    return res.status(400).json({ error: 'User already exists' });
  }
  
  let referredBy = null;
  let signupBonus = 0;
  
  // Check referral code
  if (referralCode) {
    const referrer = Array.from(users.values()).find(u => u.username === referralCode);
    if (referrer) {
      referredBy = referrer.username;
      signupBonus = adminSettings.get('referral_bonus') || 0.0001;
      
      // Give commission to referrer
      referrer.balance += adminSettings.get('referral_bonus') || 0.0001;
      referrer.referralEarnings = (referrer.referralEarnings || 0) + (adminSettings.get('referral_bonus') || 0.0001);
      referrer.referrals = (referrer.referrals || 0) + 1;
      users.set(referrer.username, referrer);
    }
  }
  
  const user = {
    username,
    email,
    wallet,
    balance: signupBonus,
    completedTasks: [],
    status: 'active', // active, banned
    isAdmin: isAdmin(email),
    createdAt: new Date(),
    referredBy,
    referrals: 0,
    referralEarnings: 0,
    totalEarnings: signupBonus
  };
  
  // Log admin registration
  if (user.isAdmin) {
    console.log(`Admin user registered: ${username} (${email})`);
  }
  
  users.set(username, user);
  res.json({ success: true, user });
});

app.post('/api/login', (req, res) => {
  const { username, email } = req.body;
  
  if (!username || !email) {
    return res.status(400).json({ error: 'Username and email required' });
  }
  
  const user = users.get(username);
  if (!user || user.email !== email) {
    return res.status(404).json({ error: 'User not found or email mismatch' });
  }
  
  if (user.status === 'banned') {
    return res.status(403).json({ error: 'Account is banned' });
  }
  
  // Update admin status if email matches
  user.isAdmin = isAdmin(email);
  users.set(username, user);
  
  console.log(`User login: ${username} (${email}) - Admin: ${user.isAdmin}`);
  
  res.json({ success: true, user });
});

// Admin routes
app.get('/api/admin/users', (req, res) => {
  const { adminEmail } = req.query;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const usersList = Array.from(users.values()).map(user => ({
    username: user.username,
    email: user.email,
    balance: user.balance,
    status: user.status,
    completedTasks: user.completedTasks.length,
    createdAt: user.createdAt
  }));
  
  res.json({ users: usersList });
});

app.post('/api/admin/user/update-balance', (req, res) => {
  const { adminEmail, username, amount, action } = req.body;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const user = users.get(username);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (action === 'add') {
    user.balance += parseFloat(amount);
  } else if (action === 'remove') {
    user.balance = Math.max(0, user.balance - parseFloat(amount));
  }
  
  users.set(username, user);
  res.json({ success: true, newBalance: user.balance });
});

app.post('/api/admin/user/ban', (req, res) => {
  const { adminEmail, username, action } = req.body;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const user = users.get(username);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  user.status = action === 'ban' ? 'banned' : 'active';
  users.set(username, user);
  
  res.json({ success: true, status: user.status });
});

app.post('/api/admin/task/add', (req, res) => {
  const { adminEmail, title, reward, type, description, url } = req.body;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const taskId = crypto.randomUUID();
  const task = {
    id: taskId,
    title,
    reward: parseFloat(reward),
    type,
    description,
    url,
    createdAt: new Date()
  };
  
  tasks.set(taskId, task);
  res.json({ success: true, task });
});

app.delete('/api/admin/task/:taskId', (req, res) => {
  const { taskId } = req.params;
  const { adminEmail } = req.query;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  if (tasks.delete(taskId)) {
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'Task not found' });
  }
});

app.post('/api/admin/settings', (req, res) => {
  const { adminEmail, faucetpayApiKey, minWithdrawalFaucetpay, minWithdrawalOther, withdrawalFeeOther, autoApproveFaucetpay, referralBonus, referralCommission } = req.body;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  if (faucetpayApiKey !== undefined) adminSettings.set('faucetpay_api_key', faucetpayApiKey);
  if (minWithdrawalFaucetpay !== undefined) adminSettings.set('min_withdrawal_faucetpay', parseFloat(minWithdrawalFaucetpay));
  if (minWithdrawalOther !== undefined) adminSettings.set('min_withdrawal_other', parseFloat(minWithdrawalOther));
  if (withdrawalFeeOther !== undefined) adminSettings.set('withdrawal_fee_other', parseFloat(withdrawalFeeOther));
  if (autoApproveFaucetpay !== undefined) adminSettings.set('auto_approve_faucetpay', autoApproveFaucetpay);
  if (referralBonus !== undefined) adminSettings.set('referral_bonus', parseFloat(referralBonus));
  if (referralCommission !== undefined) adminSettings.set('referral_commission', parseFloat(referralCommission));
  
  res.json({ success: true, message: 'Settings updated' });
});

app.get('/api/admin/settings', (req, res) => {
  const { adminEmail } = req.query;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const settings = {
    faucetpayApiKey: adminSettings.get('faucetpay_api_key'),
    minWithdrawalFaucetpay: adminSettings.get('min_withdrawal_faucetpay'),
    minWithdrawalOther: adminSettings.get('min_withdrawal_other'),
    withdrawalFeeOther: adminSettings.get('withdrawal_fee_other'),
    autoApproveFaucetpay: adminSettings.get('auto_approve_faucetpay'),
    referralBonus: adminSettings.get('referral_bonus'),
    referralCommission: adminSettings.get('referral_commission')
  };
  
  res.json({ settings });
});

app.get('/api/admin/withdrawals', (req, res) => {
  const { adminEmail } = req.query;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const withdrawalsList = Array.from(withdrawals.values());
  res.json({ withdrawals: withdrawalsList });
});

app.post('/api/admin/withdrawal/approve', (req, res) => {
  const { adminEmail, withdrawalId, action } = req.body;
  
  if (!isAdmin(adminEmail)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  const withdrawal = withdrawals.get(withdrawalId);
  if (!withdrawal) {
    return res.status(404).json({ error: 'Withdrawal not found' });
  }
  
  withdrawal.status = action === 'approve' ? 'completed' : 'rejected';
  withdrawal.processedAt = new Date();
  withdrawals.set(withdrawalId, withdrawal);
  
  res.json({ success: true, status: withdrawal.status });
});

// Get available tasks
app.get('/api/tasks/:username', (req, res) => {
  const { username } = req.params;
  const user = users.get(username);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const availableTasks = Array.from(tasks.values()).map(task => ({
    ...task,
    completed: user.completedTasks.includes(task.id)
  }));
  
  res.json({ tasks: availableTasks });
});

// Complete task
app.post('/api/complete-task', (req, res) => {
  const { username, taskId, captchaToken } = req.body;
  
  // Simple captcha verification (in production, use proper captcha service)
  if (!captchaToken || captchaToken !== 'verified') {
    return res.status(400).json({ error: 'Captcha verification failed' });
  }
  
  const user = users.get(username);
  const task = tasks.get(taskId);
  
  if (!user || !task) {
    return res.status(404).json({ error: 'User or task not found' });
  }
  
  if (user.status === 'banned') {
    return res.status(403).json({ error: 'Account is banned' });
  }
  
  if (user.completedTasks.includes(taskId)) {
    return res.status(400).json({ error: 'Task already completed' });
  }
  
  user.completedTasks.push(taskId);
  user.balance += task.reward;
  user.totalEarnings = (user.totalEarnings || 0) + task.reward;
  
  // Give commission to referrer if exists
  if (user.referredBy) {
    const referrer = users.get(user.referredBy);
    if (referrer) {
      const commission = task.reward * 0.1; // 10% commission
      referrer.balance += commission;
      referrer.referralEarnings = (referrer.referralEarnings || 0) + commission;
      users.set(referrer.username, referrer);
    }
  }
  
  users.set(username, user);
  
  res.json({ 
    success: true, 
    message: `Task completed! Earned ${task.reward} TON`,
    newBalance: user.balance 
  });
});

// Get user balance
app.get('/api/balance/:username', (req, res) => {
  const { username } = req.params;
  const user = users.get(username);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  res.json({ balance: user.balance });
});

// FaucetPay API integration
async function processFaucetPayWithdrawal(amount, address) {
  const apiKey = adminSettings.get('faucetpay_api_key');
  if (!apiKey) {
    throw new Error('FaucetPay API key not configured');
  }
  
  try {
    const response = await fetch('https://faucetpay.io/api/v1/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        api_key: apiKey,
        amount: amount,
        to: address,
        currency: 'TON',
        referral: false
      }),
    });
    
    const data = await response.json();
    return data;
  } catch (error) {
    throw new Error('FaucetPay API error: ' + error.message);
  }
}

// Withdrawal request
app.post('/api/withdraw', async (req, res) => {
  const { username, amount, method, address } = req.body;
  
  const user = users.get(username);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (user.status === 'banned') {
    return res.status(403).json({ error: 'Account is banned' });
  }
  
  const minWithdrawal = method === 'faucetpay' ? 
    adminSettings.get('min_withdrawal_faucetpay') : 
    adminSettings.get('min_withdrawal_other');
  
  if (amount <= 0 || amount > user.balance) {
    return res.status(400).json({ error: 'Invalid withdrawal amount' });
  }
  
  if (amount < minWithdrawal) {
    return res.status(400).json({ error: `Minimum withdrawal is ${minWithdrawal} TON` });
  }
  
  const withdrawalId = crypto.randomUUID();
  const autoApprove = method === 'faucetpay' && adminSettings.get('auto_approve_faucetpay');
  
  let withdrawal = {
    id: withdrawalId,
    username,
    amount,
    method,
    address,
    status: 'pending',
    createdAt: new Date(),
    processedAt: null
  };
  
  // Process FaucetPay withdrawal automatically
  if (autoApprove && method === 'faucetpay') {
    try {
      const faucetPayResult = await processFaucetPayWithdrawal(amount, address);
      if (faucetPayResult.status === 200) {
        withdrawal.status = 'completed';
        withdrawal.processedAt = new Date();
        withdrawal.txId = faucetPayResult.payout_id;
      } else {
        withdrawal.status = 'failed';
        withdrawal.error = faucetPayResult.message || 'FaucetPay processing failed';
      }
    } catch (error) {
      withdrawal.status = 'failed';
      withdrawal.error = error.message;
    }
  }
  
  // Only deduct balance if withdrawal was successful or pending
  if (withdrawal.status === 'completed' || withdrawal.status === 'pending') {
    const finalAmount = method === 'faucetpay' ? amount : amount + (adminSettings.get('withdrawal_fee_other') || 0.01);
    user.balance -= finalAmount;
    users.set(username, user);
  }
  
  withdrawals.set(withdrawalId, withdrawal);
  
  res.json({ 
    success: withdrawal.status !== 'failed', 
    message: withdrawal.status === 'completed' ? 'Withdrawal processed successfully via FaucetPay' : 
             withdrawal.status === 'pending' ? 'Withdrawal request submitted for manual review' :
             withdrawal.error,
    withdrawalId,
    newBalance: user.balance,
    status: withdrawal.status
  });
});

// Get withdrawal history
app.get('/api/withdrawals/:username', (req, res) => {
  const { username } = req.params;
  const userWithdrawals = Array.from(withdrawals.values())
    .filter(w => w.username === username);
  
  res.json({ withdrawals: userWithdrawals });
});

// Get leaderboard
app.get('/api/leaderboard', (req, res) => {
  const leaderboard = Array.from(users.values())
    .filter(user => !user.isAdmin && user.status === 'active')
    .map(user => ({
      username: user.username,
      totalEarnings: user.totalEarnings || 0,
      completedTasks: user.completedTasks.length,
      referrals: user.referrals || 0
    }))
    .sort((a, b) => b.totalEarnings - a.totalEarnings)
    .slice(0, 10);
  
  res.json({ leaderboard });
});

// Get referral stats
app.get('/api/referral-stats/:username', (req, res) => {
  const { username } = req.params;
  const user = users.get(username);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const stats = {
    referralCode: user.username,
    referrals: user.referrals || 0,
    referralEarnings: user.referralEarnings || 0,
    referralBonus: adminSettings.get('referral_bonus') || 0.1,
    referralCommission: adminSettings.get('referral_commission') || 0.2
  };
  
  res.json({ stats });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
