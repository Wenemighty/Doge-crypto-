const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');

app.use(cors());
app.use(bodyParser.json());

let users = [];
let tasks = [];
let submissions = [];
let withdrawals = [];

app.post('/api/register', (req, res) => {
    const { username, referral } = req.body;
    if (users.find(u => u.username === username)) {
        return res.status(400).json({ message: 'Username already exists' });
    }
    const user = { username, referral, balance: 0, referrals: [] };
    users.push(user);
    if (referral) {
        const refUser = users.find(u => u.username === referral);
        if (refUser) {
            refUser.referrals.push(username);
            refUser.balance += 1;
        }
    }
    res.json(user);
});

app.post('/api/login', (req, res) => {
    const { username } = req.body;
    const user = users.find(u => u.username === username);
    if (user) res.json(user);
    else res.status(404).json({ message: 'User not found' });
});

app.post('/api/tasks', (req, res) => {
    const { adminKey, task } = req.body;
    if (adminKey !== 'admin123') return res.status(403).json({ message: 'Forbidden' });
    tasks.push(task);
    res.json({ message: 'Task added' });
});

app.get('/api/tasks', (req, res) => {
    res.json(tasks);
});

app.post('/api/submit', (req, res) => {
    const { username, taskId, proof } = req.body;
    submissions.push({ username, taskId, proof, status: 'pending' });
    res.json({ message: 'Submitted' });
});

app.get('/api/submissions', (req, res) => {
    res.json(submissions);
});

app.post('/api/approve', (req, res) => {
    const { adminKey, submissionId } = req.body;
    if (adminKey !== 'admin123') return res.status(403).json({ message: 'Forbidden' });
    const sub = submissions[submissionId];
    if (sub) {
        sub.status = 'approved';
        const user = users.find(u => u.username === sub.username);
        if (user) user.balance += 2;
        res.json({ message: 'Approved' });
    } else res.status(404).json({ message: 'Not found' });
});

app.post('/api/withdraw', (req, res) => {
    const { username, wallet } = req.body;
    withdrawals.push({ username, wallet, status: 'pending' });
    res.json({ message: 'Requested' });
});

app.get('/api/withdrawals', (req, res) => {
    res.json(withdrawals);
});

app.listen(3000, () => {
    console.log('Backend server running on http://localhost:3000');
});
